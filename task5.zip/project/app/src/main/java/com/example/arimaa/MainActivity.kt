package com.example.arimaa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArimaaGame()
        }
    }
}

@Composable
fun ArimaaGame() {
    val boardSize = 8
    val trapPositions = listOf(Pair(2, 2), Pair(2, 5), Pair(5, 2), Pair(5, 5))
    val initialPiecesGold = listOf(
        "r", "r", "r", "r", "r", "r", "r", "r",
        "c", "d", "h", "m", "e", "h", "d", "c"
    )
    val initialPiecesSilver = initialPiecesGold.map { it.uppercase() }

    var boardState by remember { mutableStateOf(Array(boardSize) { Array(boardSize) { "" } }) }
    var selectedPiece by remember { mutableStateOf(Pair(-1, -1)) }
    var currentPlayer by remember { mutableStateOf("gold") }
    var moveCount by remember { mutableStateOf(0) }
    var boardHistory by remember { mutableStateOf(mutableListOf<Array<Array<String>>>()) }
    var turnRejectionMessage by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        boardState = Array(boardSize) { row ->
            Array(boardSize) { col ->
                when {
                    row == 0 -> initialPiecesGold[col]
                    row == 1 -> initialPiecesGold[col + 8]
                    row == 7 -> initialPiecesSilver[col]
                    row == 6 -> initialPiecesSilver[col + 8]
                    else -> ""
                }
            }
        }
        boardHistory.add(boardState.map { it.clone() }.toTypedArray())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Current Player: $currentPlayer",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (turnRejectionMessage.isNotEmpty()) {
            Text(
                text = turnRejectionMessage,
                color = Color.Red,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(boardSize),
            modifier = Modifier.aspectRatio(1f)
        ) {
            items(boardSize * boardSize) { index ->
                val row = index / boardSize
                val col = index % boardSize
                val isTrap = trapPositions.contains(Pair(row, col))
                val piece = boardState[row][col]

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .background(if ((row + col) % 2 == 0) Color.Gray else Color.LightGray)
                        .clickable {
                            if (selectedPiece.first == -1) {
                                if (boardState[row][col].isNotEmpty() && boardState[row][col].first().isLowerCase() == currentPlayer.first().isLowerCase()) {
                                    selectedPiece = Pair(row, col)
                                }
                            } else {
                                val selectedRow = selectedPiece.first
                                val selectedCol = selectedPiece.second
                                val validMoves = getValidMoves(selectedRow, selectedCol, boardState)
                                if (validMoves.contains(Pair(row, col))) {
                                    boardState[row][col] = boardState[selectedRow][selectedCol]
                                    boardState[selectedRow][selectedCol] = ""
                                    selectedPiece = Pair(-1, -1)
                                    moveCount++
                                    if (moveCount == 4) {
                                        currentPlayer = if (currentPlayer == "gold") "silver" else "gold"
                                        moveCount = 0
                                    }
                                    boardHistory.add(boardState.map { it.clone() }.toTypedArray())
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isTrap) {
                        Text(text = "X", fontSize = 24.sp, color = Color.Red)
                    }
                    if (piece.isNotEmpty()) {
                        Text(text = piece.uppercase(), fontSize = 24.sp, color = if (piece.first().isLowerCase()) Color.Yellow else Color.Cyan)
                    }
                }
            }
        }

        Button(
            onClick = {
                if (moveCount > 0) {
                    moveCount = 0
                    boardState = boardHistory.last().map { it.clone() }.toTypedArray()
                }
            },
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(text = "Restart Move")
        }

        Button(
            onClick = {
                if (moveCount > 0) {
                    currentPlayer = if (currentPlayer == "gold") "silver" else "gold"
                    moveCount = 0
                } else {
                    turnRejectionMessage = "No moves made or board state unchanged."
                }
            },
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(text = "Finish Turn")
        }

        Button(
            onClick = {
                boardState = Array(boardSize) { row ->
                    Array(boardSize) { col ->
                        when {
                            row == 0 -> initialPiecesGold[col]
                            row == 1 -> initialPiecesGold[col + 8]
                            row == 7 -> initialPiecesSilver[col]
                            row == 6 -> initialPiecesSilver[col + 8]
                            else -> ""
                        }
                    }
                }
                boardHistory.clear()
                boardHistory.add(boardState.map { it.clone() }.toTypedArray())
                currentPlayer = "gold"
                moveCount = 0
                selectedPiece = Pair(-1, -1)
                turnRejectionMessage = ""
            },
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(text = "Reset Game")
        }
    }
}

fun getValidMoves(row: Int, col: Int, boardState: Array<Array<String>>): List<Pair<Int, Int>> {
    val moves = mutableListOf<Pair<Int, Int>>()
    val piece = boardState[row][col]
    val directions = listOf(Pair(-1, 0), Pair(1, 0), Pair(0, -1), Pair(0, 1))

    for (dir in directions) {
        val newRow = row + dir.first
        val newCol = col + dir.second
        if (newRow in 0..7 && newCol in 0..7 && boardState[newRow][newCol].isEmpty()) {
            if (piece == "r" && dir == Pair(1, 0)) continue // Rabbits cannot move backward
            moves.add(Pair(newRow, newCol))
        }
    }

    return moves
}